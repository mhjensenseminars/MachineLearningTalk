#include "optimizer.h"

Optimizer::Optimizer()
{

}
